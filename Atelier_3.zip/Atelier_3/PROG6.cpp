#include<iostream>
using namespace std;

class Personne {
	private :
		      string nom;
		      string prenom;
		      string date_naissance;
	public:
		  Personne(string nom,string prenom,string date_naissance)
		   {
		   	this->nom=nom;
		   	this->prenom=prenom;
		   	this->date_naissance=date_naissance;
		   }
	    virtual void afficher()
	          {
	          	cout <<"Nom="<<nom<<" Prenom="<<prenom<<" date de naissance="<<date_naissance;
			  }
};

class Employe:public Personne {
	
	protected :
		        float salaire;
	public :
		     Employe(string nom,string prenom,string date_naissance,float salaire) : Personne(nom,prenom,date_naissance)
		     {
		     	this->salaire=salaire;
			 }
		void afficher()
		{
			Personne::afficher();
			cout <<" Salaire= "<<salaire <<" ";
		}
        
	
};

class Chef:public Employe{
	protected :
		        string service;
	public :
		    Chef(string nom,string prenom,string date_naissance,float salaire,string service) : Employe(nom,prenom,date_naissance,salaire)
		    {
		    	this->service=service;
			}
		void afficher()
		{
			Employe::afficher();
			cout<<"Service="<<service<<"";
		}
	
};

int main()
{
	int i;
	Personne *T[5];
	T[0]=new  Personne("N1","P1","D1");
	T[1]=new  Employe("N2","P2","D2",2000);
	T[2]=new  Chef("N3","P3","D3",1999,Gestion);
	
	for(i=0;i<3;i++)
	 {
	    T[i]->afficher();
		cout<<endl;	
	 }
	    
	

}
