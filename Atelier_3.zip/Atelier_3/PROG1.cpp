#include <iostream>

using namespace std;

class myclass
{
private:
    string my_nom;

public:

    myclass();
    ~myclass();

};

myclass::myclass()
{
    string nom;
    cout<<"enter votre nom:"<<endl ;
    cin>>nom;
    myclass.my_nom=nom;

}
myclass::~myclass()
{
    cout<<"au revoir " <<endl;

}



int main()
{
    myclass c ;
    return 0;
}
