#include <iostream>
using namespace std;

class Animal
{

protected:
    string name;
    int age;

public:
    Animal(string name,int age)
    {
        this->name=name;
        this->age=age;
    }
    void set_value(int age)
    {
        this->age=age;
    }
    void afficher()
    {
        cout<<"je suis un animale, mon nom est "<<name<<"et j'ai:"<<age<<endl;
    }
};
class Zebra : public Animal
{
private:
    string origine;
public:
    Zebra(int age,string name,string origine)
    {
        Animal(name,age);
        this->origine=origine;
    }
    void afficher()
    {
        Animal::afficher();
        cout<<"race: Zebra et Mon origine"<<origine<<endl;
    }
};
class Dolphin : public Animal
{
private:
    string origine;
public:
    Dolphin(int age,string name,string origine):Animal(name,age)
    {
        this->origine=origine;
    }
    void afficher()
    {
        Animal::afficher();
        cout<<"race: dolphin Mon origine"<<origine<<endl;
    }
};
int main()
{
    Zebra Z(20,"Z1","Afrique");
    Dolphin D(4,"D1","Asia");

    Z.afficher();
    Z.set_value(13);
    Z.afficher();

    D.afficher();
    D.set_value(7);
    D.afficher();
}
