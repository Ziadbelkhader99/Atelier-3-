#include <iostream>

using namespace std;

class Media {

protected:
     char *titre;

public:
    void imprimer(){

        cout << "Je suis la classe Media !! \nDonner un titre :" <<endl;
        char *tmp = new char[100];
        cin >> tmp;
        titre = &tmp[0];
    }
    char *id(){
        return titre;
    }
};



class Audio: public Media { // Sous-classe de Media ********************************
protected:
     char *titre;

public:
    void imprimer(){

        cout << "Je suis la classe Audio !! \nDonner un titre :" <<endl;
        char *tmp = new char[100];
        cin >> tmp;
        titre = &tmp[0];
    }
    char *id(){
        return titre;
    }
};

// Les sous-classes de la classe Audio

class CD: public Audio {

public:
    void imprimer(){

        cout << "Je suis la classe CD, Sous-classe de Audio !! \nDonner un titre :" <<endl;
        char *tmp = new char[100];
        cin >> tmp;
        titre = &tmp[0];
    }
    char *id(){
        return titre;
    }
};


class Cassette: public Audio {

public:
    void imprimer(){

        cout << "Je suis la classe Cassette, Sous-classe de Audio !! \nDonner un titre :" <<endl;
        char *tmp = new char[100];
        cin >> tmp;
        titre = &tmp[0];
    }
    char *id(){
        return titre;
    }
};


class Disque: public Audio {

public:
    void imprimer(){

        cout << "Je suis la classe Disque, Sous-classe de Audio !! \nDonner un titre :" <<endl;
        char *tmp = new char[100];
        cin >> tmp;
        titre = &tmp[0];
    }
    char *id(){
        return titre;
    }
};

//---------------------------------

class Livre: public Media { // Sous-classe de Media *******************************
protected:
     char *titre;

public:
    void imprimer(){

        cout << "Je suis la classe Livre !! \nDonner un titre :" <<endl;
        char *tmp = new char[100];
        cin >> tmp;
        titre = &tmp[0];
    }
    char *id(){
        return titre;
    }
};


class Presse: public Media { // Sous-classe de Media *******************************
protected:
     char *titre;

public:
    void imprimer(){

        cout << "Je suis la classe Presse !! \nDonner un titre :" <<endl;
        char *tmp = new char[100];
        cin >> tmp;
        titre = &tmp[0];
    }
    char *id(){
        return titre;
    }
};

// Les sous-classes de la classe Presse

class Magazine: public Presse {

public:
    void imprimer(){

        cout << "Je suis la classe Magazine, Sous-classe de Presse !! \nDonner un titre :" <<endl;
        char *tmp = new char[100];
        cin >> tmp;
        titre = &tmp[0];
    }
    char *id(){
        return titre;
    }

};

class Journal: public Presse {

public:
    void imprimer(){

        cout << "Je suis la classe Journal, Sous-classe de Presse !! \nDonner un titre :" <<endl;
        char *tmp = new char[100];
        cin >> tmp;
        titre = &tmp[0];
    }
    char *id(){
        return titre;
    }
};

class Revue: public Presse {

public:
    void imprimer(){

        cout << "Je suis la classe Revue, Sous-classe de Presse !! \nDonner un titre :" <<endl;
        char *tmp = new char[100];
        cin >> tmp;
        titre = &tmp[0];
    }
    char *id(){
        return titre;
    }
};

//---------------------------------


int main(){

    Media *M = new Media();
    Cassette *C = new Cassette();
    Livre L;
    Journal J;
    Presse P;

    M->imprimer();
    cout << "Mon titre de Media est : " <<M->id() << endl;

    C->imprimer();
    cout << "Mon titre de Cassette est : " <<C->id()<< endl;

    L.imprimer();
    cout << "Mon titre de Livre est : " << L.id()<< endl;

    J.imprimer();
    cout << "Mon titre de Journal est : " <<J.id()<< endl;

    P.imprimer();
    cout << "Mon titre de Presse est : " <<P.id()<< endl;

    return 0;
}
