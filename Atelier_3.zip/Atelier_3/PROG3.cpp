
#include <iostream>
#include <cmath>

using namespace std;

class complexe {
    double Re;
    double Img;

public:
    complexe(double a = 0, double b = 0)
    {
        Re = a;
        Img = b;
    }
    void afficher()
    {
        cout << Re;

        //Pour ne pas afficher 4 + -6i (si Img est negatif)
        if (Img >= 0)
            cout << " + ";

        cout << Img << "i" << endl;
    }
    double module(complexe a)
    {
        return sqrt(a.Re * a.Re + a.Img * a.Img);
    }
    complexe conjugue(complexe a)
    {
        a.Re = Re;
        a.Img = -Img;
        return a;
    }

    //Op�rateur : complexe + complexe
    complexe operatorAjt(complexe a, complexe b)
    {
        complexe s;
        s.Re = a.Re + b.Re;
        s.Img = a.Img + b.Img;
        return s;
    }


    //Op�rateur : complexe - complexe
    complexe operatorSous(complexe a, complexe b)
    {
        complexe s;
        s.Re = a.Re - b.Re;
        s.Img = a.Img - b.Img;
        return s;
    }

    //Op�rateur : complexe * complexe
    complexe operatorMulti(complexe a, complexe b)
    {
        complexe p;
        p.Re = a.Re * b.Re - a.Img * b.Img;
        p.Img = a.Re * b.Img + a.Img * b.Re;
        return p;
    }
    //Op�rateur : complexe / complexe
    complexe operatorDiv(complexe a, complexe b)
    {
        complexe d, inv; // methode
        inv.Re = 1 / module(b);
        inv.Img = 0;
        complexe m = operatorMulti(a, conjugue(b));
        d = operatorMulti(m, inv);
        return d;
    }
};
int main()
{
    complexe a(1, 3), b(2, 7), c;

    cout << "A = ";
    a.afficher();
    cout << "B = ";
    b.afficher();

    cout << "A + B = ";
    c = c.operatorAjt(a, b);
    c.afficher();

    cout << "A * B = ";
    c = c.operatorMulti(a, b);
    c.afficher();

    cout << "B - A = ";
    c = c.operatorSous(b, a);
    c.afficher();

    cout << "B / A = ";
    c = c.operatorDiv(b, a);
    c.afficher();

    return 0;
}
